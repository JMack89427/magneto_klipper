# Contact

There are several ways to contact people who can assist with issues. Discord is going to be the quickest response as
there will be more people in the chat who can help.

## GitHub Issues
You may submit a GitHub issue request for any problems you are having.

## Klipper Community Discord

[Look for the channel `#klipper-screen`](https://discord.klipper3d.org/)
